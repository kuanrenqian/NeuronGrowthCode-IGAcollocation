function [matdx] = gradient1D_mat(mat,dx)
%--
%-- this function uses imfilter to compute the discrete gradients
%--

% Prewitt filters
matdx = zeros(size(mat,1),1);
for i = 2:size(mat,1)-1
    matdx(i,1) = (mat(i+1) - mat(i-1,1))*(1/2*dx);
end
matdx(1,1) = matdx(2,1);
matdx(size(mat,1),1) = matdx(size(mat,1)-1,1);
end
