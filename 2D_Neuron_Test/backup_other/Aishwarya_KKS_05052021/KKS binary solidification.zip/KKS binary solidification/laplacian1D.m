function [grad] =laplacian1D(m,dx)
% Compute the discrete laplacian of the matrix m using imfilter

% 5-point stencil
%lap_filter = [1, -2, 1]/(dx^2);

% 9-point stencil
%lap_filter = [0.25, 0.5, 0.25; 0.5, -3, 0.5; 0.25, 0.5, 0.25]/(dx*dy);

%grad = imfilter(m, lap_filter, 'circular');
grad = zeros(size(m,1),1);
for i = 2:size(m,1)-1
    grad(i,1) = (m(i+1) - 2* m(i,1) + m(i-1,1))*(1/dx^2);
end
grad(1,1) = grad(2,1);
grad(size(m,1),1) = grad(size(m,1)-1,1);
end