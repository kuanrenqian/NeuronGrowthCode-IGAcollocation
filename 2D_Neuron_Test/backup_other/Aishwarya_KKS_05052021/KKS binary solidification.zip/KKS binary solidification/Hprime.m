function val = Hprime(phi)

%val = 30.*phi.^2.*(1-phi).^2;
val = 1;

end