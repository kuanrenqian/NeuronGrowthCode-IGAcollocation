function val = linearGdoublePrime(phi)

val = -4.*ones(size(phi,1),size(phi,2));

end