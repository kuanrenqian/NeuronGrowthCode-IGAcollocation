function val = linearGPrime(phi)

val = 2.*(1-2.*phi);

end