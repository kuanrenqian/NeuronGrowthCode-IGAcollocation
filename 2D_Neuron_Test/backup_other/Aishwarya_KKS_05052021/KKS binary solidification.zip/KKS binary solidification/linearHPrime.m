function val = linearHPrime(phi)

val = 30.*phi.*(1-phi);

end