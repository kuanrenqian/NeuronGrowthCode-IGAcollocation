function F = dfLdc(C)

calCl = [6.18692878e+03,-3.09579439e+04, 6.68516329e+04,-8.15779791e+04,6.19257214e+04,-3.03841489e+04, 9.74145735e+03,-2.04379606e+03,2.94796431e+02,-3.39127135e+01,-6.26373908e+01];
F = zeros(size(C,1),size(C,2));
for i = 1:size(F,1)
    for j = 1:size(F,2)
        F(i,j) = 10.0*calCl(1)*(C(i,j)^9) + 9.0*calCl(2)*(C(i,j)^8) + 8.0*calCl(3)*(C(i,j)^7) + 7.0*calCl(4)*(C(i,j)^6) + 6.0*calCl(5)*(C(i,j)^5) + 5.0*calCl(6)*(C(i,j)^4) + 4.0*calCl(7)*(C(i,j)^3) + 3.0*calCl(8)*(C(i,j)^2) + 2.0*calCl(9)*C(i,j) + calCl(10);
    end
end
end