function [cs, cl] = interpolateCsCl(pureCs,pureCl,LUX,LUY, phi, conc)

interpolateCs = zeros(size(phi,1),1);
interpolateCl = zeros(size(phi,1),1);

for i =1:size(phi,1)
    interpolateCs(i,1) = interp2(LUX, LUY, pureCs, phi(i,1), conc(i,1), 'spline');
    interpolateCl(i,1) = interp2(LUX, LUY, pureCl, phi(i,1), conc(i,1), 'spline');
    interpolateCs(i,1)
    interpolateCl(i,1)
end

cs = interpolateCs;
cl = interpolateCl;
end