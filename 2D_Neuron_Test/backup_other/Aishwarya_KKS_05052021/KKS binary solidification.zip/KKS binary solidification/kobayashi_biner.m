%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PHASE-FIELD FINITE-DIFFRENCE %
%
% CODE FOR
%
% DENDRITIC SOLIDIFICATION
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%== get initial wall time:
clc
clear all
close all

time0 = clock();
format long;
%-- Simulation cell parameters:
Nx = 1000;
Ny = 1000;
NxNy = Nx*Ny;
dx = 0.03;
dy = 0.03;
%--- Time integration parameters:
nstep = 6000;
nprint = 100;
dtime = 1e-4;

%--- Material specific parameters:
tau = 0.0003;
epsilonb = 0.01;
mu = 1.0;
kappa = 1.8;
delta = 0.5;
aniso = 2.0;
alpha = 0.9;
gamma = 10.0;
teq = 1.0;
theta0 = 0.0;
seed = 10.0;
%
pix=4.0*atan(1.0);
%--- Initialize and introduce
% initial nuclei:
[phi,tempr] = nucleus(Nx,Ny,seed);

%---
%--- Evolution
%---
for istep =1:nstep
    phiold =phi;
    %---
    % calculate the laplacians
    %and epsilon:
    %---    
    lap_phi = laplacian_imf(phi, dx, dy);
    %--
    lap_tempr = laplacian_imf(tempr, dx, dy);
    %--gradients of phi:
    [phidy,phidx]=gradient_mat_imf(phi,dx,dy);
    %-- calculate angle:
    theta =atan2(phidy,phidx)+pi/2;
    %--- epsilon and its derivative:
    epsilon = epsilonb*(1.0+delta*cos(aniso*(theta-theta0)));
    epsilon_deriv = -epsilonb*aniso*delta*sin(aniso.*(theta-theta0));
    %--- first term:
    dummyx =epsilon.*epsilon_deriv.*phidx;
    [term1,~] =gradient_mat_imf(dummyx,dx,dy);
    %--- second term:
    dummyy =-epsilon.*epsilon_deriv.*phidy;
    [~,term2] =gradient_mat_imf(dummyy,dx,dy);
    %--- factor m:
    m =(alpha/pix)*atan(gamma*(teq-tempr));
    %-- Time integration:
    phi = phi +(dtime/tau) *(term1 +term2 + epsilon.^2 .* lap_phi + ...
        phiold.*(1.0-phiold).*(phiold - 0.5 + m));
    
    %-- evolve temperature:
    tempr = tempr + dtime*lap_tempr + kappa*(phi-phiold);
    %---- print results
    if(mod(istep,nprint) == 0 )
        fprintf('done step: %5d\n',istep);
        subplot(1,2,1)
        imagesc(phi)
        title("\phi")
        colorbar
        subplot(1,2,2)
        imagesc(tempr)
        title("tempr")
        colorbar
        drawnow 
    end %if
end %istep
%--- calculate compute time:
compute_time = etime(clock(), time0);
fprintf('Compute Time: %10d\n', compute_time);



