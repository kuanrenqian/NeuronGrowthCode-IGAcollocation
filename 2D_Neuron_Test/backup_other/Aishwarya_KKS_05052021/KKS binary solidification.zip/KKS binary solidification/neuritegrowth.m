clear
close all
addpath(genpath("."))

param = setparameters_neurite();
final_size = 400;
%% Initialization of variables

[phi,conc,conc_t,theta,tempr] =nucleus_tubulin(param.Nx,param.Ny,param.seed);
phi_original = phi;
phi3 = zeros(param.Nx,param.Ny);

theta_original = theta;

figure
imagesc(phi)

[phi,conc,conc_t,theta] = neurite_growth_phasefield_vec_fd(param,phi,conc,conc_t,tempr,theta);


