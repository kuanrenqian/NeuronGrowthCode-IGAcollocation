function F = fS(C)
calCs = [6.19383857e+03,-3.09926825e+04, 6.69261368e+04,-8.16668934e+04,6.19902973e+04,-3.04134700e+04, 9.74968659e+03,-2.04529002e+03,2.95622845e+02,-3.70962613e+01,-6.12900561e+01];
F = zeros(size(C,1),size(C,2));
for i = 1:size(C,1)
    for j =1:size(C,2)
        F(i,j) = calCs(1)*(C(i,j)^10) + calCs(2)*(C(i,j)^9) + calCs(3)*(C(i,j)^8) + calCs(4)*(C(i,j)^7) + calCs(5)*(C(i,j)^6) + calCs(6)*(C(i,j)^5) + calCs(7)*(C(i,j)^4) + calCs(8)*(C(i,j)^3) + calCs(9)*(C(i,j)^2) + calCs(10)*C(i,j) + calCs(11);
    end
end
end