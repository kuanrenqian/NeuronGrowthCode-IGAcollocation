%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PHASE-FIELD FINITE-DIFFRENCE %
%
% CODE FOR
%
% DENDRITIC SOLIDIFICATION
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%== get initial wall time:
clc
clear all
close all

time0 = clock();
format long;
%-- Simulation cell parameters:
Nx = 500;
Ny = 500;
NxNy = Nx*Ny;
dx = 0.03;
dy = 0.03;
%--- Time integration parameters:
nstep = 6000;
nprint = 100;
dtime = 1e-4;

%--- Material specific parameters:
tau = 0.0003;
epsilonb = 0.01;
mu = 1.0;
kappa = 1.8;
delta = 0.5;
aniso = 2.0;
alpha = 0.9;
gamma = 10.0;
teq = 1.0;
theta0 = 0.0;
seed = 30.0;
s_coeff = 1e-6;
s_coeff1 = s_coeff.*ones(Nx,Ny);
%
pix=4.0*atan(1.0);
%--- Initialize and introduce
% initial nuclei:
[phi,tempr,theta] = nucleus(Nx,Ny,seed);

%---
%--- Evolution
%---
for istep =1:nstep
    phiold =phi;
    %---
    % calculate the laplacians
    %and epsilon:
    %---
    lap_phi = laplacian_imf(phi, dx, dy);
    %--
    lap_tempr = laplacian_imf(tempr, dx, dy);
    %--gradients of phi:
    [phidy,phidx]=gradient_mat_imf(phi,dx,dy);
    %-- calculate angle:
    psi =atan2(phidy,phidx)+pi/2;
    xtheta = 0;% 2*pi*theta;
    %--- epsilon and its derivative:
    epsilon = epsilonb*(1.0+delta*cos(aniso*(psi-xtheta)));
    epsilon_deriv = -epsilonb*aniso*delta*sin(aniso.*(psi-xtheta));
    %--- first term:
    dummyx =epsilon.*epsilon_deriv.*phidx;
    [term1,~] =gradient_mat_imf(dummyx,dx,dy);
    %--- second term:
    dummyy =-epsilon.*epsilon_deriv.*phidy;
    [~,term2] =gradient_mat_imf(dummyy,dx,dy);
    %--- factor m:
    m =(alpha/pix)*atan(gamma*(teq-tempr));
    [thetadx,thetady] = gradient_mat_imf(theta,dx,dy);
    %p(phi) calculation
    p_phi = (phi.^3).*(10-15.*phi+6.*(phi.^2));
    %evaluate absolute value of theta
    theta_absolute = sqrt(thetadx.^2+thetady.^2)+1e-6;
    % calculate q(phi)
    q_phi = phi.^2*(1-phi).^2;
    %-- Time integration:
    phi = phi +(dtime/tau) *(term1 +term2 + epsilon.^2 .* lap_phi + ...
        phiold.*(1.0-phiold).*(phiold - 0.5 + m) -...
        (30*s_coeff1).*q_phi.*theta_absolute);
    
    %-- evolve temperature:
    tempr = tempr + dtime*lap_tempr + kappa*(phi-phiold);
    

    %calculate terms for theta evaluation
    
    dummyx = p_phi.*s_coeff1.*(thetadx./theta_absolute);
    [termx,~] = gradient_mat_imf(dummyx,dx,dy);
    
    dummyy = p_phi.*s_coeff1.*(thetady./theta_absolute);
    [~,termy] = gradient_mat_imf(dummyy,dx,dy);
    
    %evolve theta
    M_theta = 1.0;
    theta = theta + M_theta*(dtime/tau)*(termx+termy);

    %---- print results
    %if(mod(istep,nprint) == 0 )
        fprintf('done step: %5d\n',istep);
        subplot(1,3,1)
        imagesc(phi)
        title("\phi")
        colorbar
        subplot(1,3,2)
        imagesc(tempr)
        title("tempr")
        colorbar
        subplot(1,3,3)
        imagesc(theta)
        title("theta")
        drawnow
    %end %if
end %istep
%--- calculate compute time:
compute_time = etime(clock(), time0);
fprintf('Compute Time: %10d\n', compute_time);