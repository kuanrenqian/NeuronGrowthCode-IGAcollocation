function [phi,conc] = nucleus_tan(Nx,Ny,dx,dy,seed)

format long;

%for i�1:Nx
%for j�1:Ny

%phi(i,j) � 0.0;
%tempr(i,j) � 0.0;

%end
%end

phi = zeros(Nx,Ny);
conc = 0.75.*ones(Nx,Ny);


for i=1:Nx
    for j=1:Ny
        dist=sqrt(((i-Nx/2)*dx)^2 +((j-Ny/2)*dy)^2)-seed*dx;
        phi(i,j) = -tanh(dist/sqrt(2.0));
        conc(i,j) = 0.5;
        
    end
end

end %endfunction