clc
clear all
close all
format long

dx2 = 0.1;
dy2 = 0.1;
nx2 = 100;
ny2 = 100;
dV2 = dx2*dy2;

Cle = 0.394;
Cse = 0.5413;
k = Cse/Cle;
initConc = Cle + 0.50*(Cse-Cle);
delta=0.5;
aniso= 6.0;
abar = 0.45;
epsilonb = 0.1;

x2 = 0:dx2:nx2*dx2;
y2 = 0:dy2:ny2*dy2;
[X,Y] = meshgrid(x2,y2);
phi = zeros(size(X,1),size(X,2));
conc = initConc*ones(size(X,1),size(X,2));
for i = 1:nx2
    for j = 1:ny2
        if(((X(j,i) - (nx2/2)*dx2)^2 + (Y(j,i) - (ny2/2)*dy2)^2)<(15*dx2)^2)
            phi(j,i) = 1;
        end
    end
end

figure
imagesc(phi)
colormap jet

figure
imagesc(conc)
colormap jet

%% Look Up Table for interpolation of Cs and Cl
LUTnp = 1002;
LUTnc = 1002;
LUTdp = 1./(LUTnp-2);
LUTdc = 1./(LUTnp-2);
flag1 = 1;

if(flag1==0)
    pureCs = zeros(LUTnp, LUTnc);
    pureCl = zeros(LUTnp, LUTnc);
    
    for i1 = 1:LUTnp
        for  j1 = 1:LUTnc
            LUTp = (i1-1)*LUTdp;
            LUTc = (j1-1)*LUTdc;
            [pureCs(i1,j1),pureCl(i1,j1)] = commonTangentConc(LUTp, LUTc, LUTc, LUTc);
        end
    end
else
    load 'pureCs.mat';
    load 'pureCl.mat';
end

% figure
% imagesc(pureCs)
%
% figure
% imagesc(pureCl)

LUTp  = linspace(-LUTdp, 1+LUTdp, LUTnp);
LUTc  = linspace(-LUTdc, 1+LUTdc, LUTnc);
[LUX, LUY] = meshgrid(LUTc,LUTp);
%[cs, cl] = interpolateCsCl(pureCs,pureCl,LUX,LUY, phi, conc);

smoothpureCs = interp2(pureCs,LUX,LUY, 'spline');
smoothpureCl = interp2(pureCl,LUX,LUY, 'spline');

% figure
% imagesc(smoothpureCs)
%
% figure
% imagesc(smoothpureCl)

Cs = zeros(size(phi,1),size(phi,2));
Cl = zeros(size(phi,1),size(phi,2));
for i =1:size(phi,1)
    for j = 1:size(phi,2)
        [Cs(i,j),Cl(i,j)] = commonTangentConc(phi(i,j), conc(i,j), conc(i,j), conc(i,j));
    end
end

figure
imagesc(Cs)
caxis([0 1])
colormap jet

figure
imagesc(Cl)
caxis([0 1])
colormap jet

%% Now start the solver for phase field
dtime = 1e-4;
nstep = 5000;
epsSq = 1.25;
halfWidth = 5.0;

figure
for istep = 1:nstep

    istep

    phiold = phi;
    concold = conc;
    Csold = Cs;
    Clold = Cl;

    %Cll = zeros(size(Cl,1),1);
    omegaVal = omega(dx2);
    fLCL = fL(Cl);
    fSCS = fS(Cs);
    dfLdC = dfLdc(Cl);

    Gprime = linearGPrime(phiold);
    Gdoubleprime = linearGdoublePrime(phiold);
    Hprimee = linearHPrime(phiold);
	Hdoubleprimee = linearHdoublePrime(phiold);

    diffusionPotential = fLCL - fSCS - dfLdC.*(Cl-Cs);

    mPhi = omegaVal.*Gprime + Hprimee.*diffusionPotential;

    dmPhidPhi = omegaVal.*Gdoubleprime + Hdoubleprimee.*diffusionPotential;

    S1 = dmPhidPhi.*phiold.*(1-phiold) + mPhi.*(1-2.*phiold);

    S0 = mPhi.*phiold.*(1-phiold) - S1.*phiold;

    lap_phi = laplacian_imf(phiold, dx2, dy2);

    %-- calculate angle:
    [phidy, phidx] = gradient_mat_imf(phiold,dx2, dy2);
    atheta = atan2(phidy,phidx);
    xtheta = 0.02;
        
    epsilon = epsilonb*(1.0+delta*cos(aniso*(atheta-xtheta)));
    epsilon_deriv = -epsilonb*aniso*delta*sin(aniso.*(atheta-xtheta));
    
    %calculate first term in phi equation:
    dummyx = epsilon.*epsilon_deriv.*phidx;
    [term1,~] = gradient_mat_imf(dummyx,dx2,dy2);
    
    %calculate second term in phi equation:
    dummyy =-epsilon.*epsilon_deriv.*phidy;
    [~,term2] =gradient_mat_imf(dummyy,dx2,dy2);
    
    delta_phi = term1 +term2 + epsilon.^2.*lap_phi + S0 + S1.*phiold;

    xi = -1 + 2.*rand(nx2+1,ny2+1);
    pertub = 0.01;    
    gphi = phiold.^2.*(1-phiold.^2);
    phi = phiold + dtime.*delta_phi+ 16.*xi.*gphi.*pertub;

    %concentration
    Qphi = evaluateQ(phiold, k);
    Dc = Qphi;
    Dp = Qphi.*Hprime(phiold).*(Cl-Cs);

    lap_conc = laplacian_imf(concold, dx2, dy2);
    diff_term = Dc.*lap_conc;
    [phidy, phidx] = gradient_mat_imf(phiold,dx2, dy2);

    [dum, explicitsource_term_x] = gradient_mat_imf(Dp.*(phidx),dx2,dy2);
    [explicitsource_term_y, dum] = gradient_mat_imf(Dp.*(phidy),dx2,dy2);
    explicitsource_term = explicitsource_term_x + explicitsource_term_y;
    
    delta_conc = diff_term + explicitsource_term;

    conc = concold + dtime.*delta_conc;

    for i =1:size(phi,1)
        for j = 1:size(phi,2)
        [Cs(i,j),Cl(i,j)] = commonTangentConc(phi(i,j), conc(i,j), conc(i,j), conc(i,j));
        end
    end

%     max(delta_phi(:))
%
%     max(delta_conc(:))

    subplot(2,2,1)
    imagesc(phi)
    colormap jet

    subplot(2,2,2)
    imagesc(conc)
    colormap jet

    subplot(2,2,3)
    imagesc(Cs)
    colormap jet

    subplot(2,2,4)
    imagesc(Cl)
    colormap jet
    drawnow
end