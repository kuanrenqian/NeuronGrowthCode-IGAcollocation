clc
clear all
close all
format long

dx1 = 0.075;
nx1 = 512;
L = nx1*dx1;

Cle = 0.394;
Cse = 0.5413;
k = Cse/Cle;
initConc = Cle + 0.50*(Cse-Cle);

x1 = 0:dx1:nx1*dx1;
x = x1';
phi = zeros(size(x,1),1);
conc = initConc*ones(size(x,1),1);
for i = 1:nx1
    if(x(i,1)< L/8)
        phi(i,1) = 1;
    end
end

figure
plot(x,phi)

figure
plot(x,conc)

%% Look Up Table for interpolation of Cs and Cl
LUTnp = 1002;
LUTnc = 1002;
LUTdp = 1./(LUTnp-2);
LUTdc = 1./(LUTnp-2);
flag1 = 1;

if(flag1==0)
    pureCs = zeros(LUTnp, LUTnc);
    pureCl = zeros(LUTnp, LUTnc);
    
    for i1 = 1:LUTnp
        for  j1 = 1:LUTnc
            LUTp = (i1-1)*LUTdp;
            LUTc = (j1-1)*LUTdc;
            [pureCs(i1,j1),pureCl(i1,j1)] = commonTangentConc(LUTp, LUTc, LUTc, LUTc);
        end
    end
else
    load 'pureCs.mat';
    load 'pureCl.mat';
end

% figure
% imagesc(pureCs)
% 
% figure
% imagesc(pureCl)

LUTp  = linspace(-LUTdp, 1+LUTdp, LUTnp);
LUTc  = linspace(-LUTdc, 1+LUTdc, LUTnc);
[LUX, LUY] = meshgrid(LUTc,LUTp);
%[cs, cl] = interpolateCsCl(pureCs,pureCl,LUX,LUY, phi, conc);

smoothpureCs = interp2(pureCs,LUX,LUY, 'spline');
smoothpureCl = interp2(pureCl,LUX,LUY, 'spline');

% figure
% imagesc(smoothpureCs)
% 
% figure
% imagesc(smoothpureCl)

Cs = zeros(size(phi,1),1);
Cl = zeros(size(phi,1),1);
for i =1:size(phi,1)
    [Cs(i,1),Cl(i,1)] = commonTangentConc(phi(i), conc(i), conc(i), conc(i));
end

figure
plot(x,Cs)

figure
plot(x,Cl)

%% Now start the solver for phase field
dtime = 0.0018;
nstep = 5000;
epsSq = 1.25;
halfWidth = 5.0;

figure
for istep = 1:nstep
    
    istep 
    
    phiold = phi;
    concold = conc;
    Csold = Cs;
    Clold = Cl;
    
    %Cll = zeros(size(Cl,1),1);
    omegaVal = omega(dx1);
    fLCL = fL(Cl);
    fSCS = fS(Cs);
    dfLdC = dfLdc(Cl);
    
    Gprime = linearGPrime(phiold);
    Gdoubleprime = linearGdoublePrime(phiold);
    Hprimee = linearHPrime(phiold);
	Hdoubleprimee = linearHdoublePrime(phiold);
    
    diffusionPotential = fLCL - fSCS - dfLdC.*(Cl-Cs);
    
    mPhi = -omegaVal.*Gprime + Hprimee.*diffusionPotential;
    
    dmPhidPhi = -omegaVal.*Gdoubleprime + Hdoubleprimee.*diffusionPotential;
    
    S1 = dmPhidPhi.*phiold.*(1-phiold) + mPhi.*(1-2.*phiold);
    
    S0 = mPhi.*phiold.*(1-phiold) - S1.*phiold;
    
    lap_phi = laplacian1D(phiold, dx1);
    
    delta_phi = epsSq.*lap_phi + S0 + S1.*phiold;
    
    phi = phiold + dtime.*delta_phi;
    
    %concentration
    Qphi = evaluateQ(phiold, k);
    Dc = Qphi;
    Dp = Qphi.*Hprime(phiold).*(Cl-Cs);
    
    lap_conc = laplacian1D(concold, dx1);
    diff_term = Dc.*lap_conc;
    phidx = gradient1D_mat(phiold,dx1);
    
    explicitsource_term = gradient1D_mat(Dp.*(phidx),dx1);
    
    delta_conc = diff_term + explicitsource_term;
    
    conc = concold + dtime.*delta_conc;
    
    for i =1:size(phi,1)
        [Cs(i,1),Cl(i,1)] = commonTangentConc(phi(i,1), conc(i,1), conc(i,1), conc(i,1));
    end
    
%     max(delta_phi(:))
%     
%     max(delta_conc(:))
    
    subplot(2,2,1)
    plot(x,phi)
    
    subplot(2,2,2)
    plot(x,conc)
    
    subplot(2,2,3)
    plot(x,Cs)
    
    subplot(2,2,4)
    plot(x,Cl)
    drawnow
end
