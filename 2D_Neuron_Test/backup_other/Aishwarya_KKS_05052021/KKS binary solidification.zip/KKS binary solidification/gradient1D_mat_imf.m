function [matdx] = gradient1D_mat_imf(mat,dx)
%--
%-- this function uses imfilter to compute the discrete gradients
%--

% Prewitt filters
filter_x = [-1, 0, 1]/(2*dx);

matdx = imfilter(mat, filter_x, 'circular');
end
