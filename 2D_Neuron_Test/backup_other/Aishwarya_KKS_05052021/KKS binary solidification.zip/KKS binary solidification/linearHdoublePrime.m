function val = linearHdoublePrime(phi)

val = 30.*(1-2.*phi);

end