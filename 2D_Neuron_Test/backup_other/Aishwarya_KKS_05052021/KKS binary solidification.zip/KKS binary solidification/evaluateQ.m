function val = evaluateQ(phi,k)

Qmin = 0.01;
val = Qmin + (1-Qmin).*(1-phi)./(1+k-(1-k).*phi);

end