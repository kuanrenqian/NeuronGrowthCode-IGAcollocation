function [Cs,Cl] = commonTangentConc(phi, c, guessCs, guessCl)
%h_phi = phi.^3.*(10 - 15.*phi + 6.*phi.^2);
h_phi = phi;

function F = root2d(C)

F(1) = h_phi*C(1,1) + (1-h_phi)*C(1,2) - c;
F(2) = dfSdc(C(1,1)) - dfLdc(C(1,2));
end
options = optimset('Display','off');
fun = @root2d;
x0 = [guessCs,guessCl];
x = fsolve(fun,x0,options);
Cs = x(1,1);
Cl = x(1,2);
end