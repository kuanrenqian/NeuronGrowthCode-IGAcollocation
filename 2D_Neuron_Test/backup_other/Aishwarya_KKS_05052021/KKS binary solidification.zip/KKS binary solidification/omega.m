function omegaVal = omega(dx)

epsSq = 1.25;
halfWidth = 5.0;

omegaVal = 2*epsSq*(2.5/(halfWidth*dx))^2;

end